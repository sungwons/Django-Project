from django.apps import AppConfig


class BkuserConfig(AppConfig):
    name = 'bkuser'
